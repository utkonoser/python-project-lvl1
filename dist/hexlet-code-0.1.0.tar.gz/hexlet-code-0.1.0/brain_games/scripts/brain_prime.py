

from brain_games.games.cli_prime import brain_prime


def main():
    print("Welcome to the Brain Games!")
    brain_prime()


if __name__ == '__main__':
    main()
