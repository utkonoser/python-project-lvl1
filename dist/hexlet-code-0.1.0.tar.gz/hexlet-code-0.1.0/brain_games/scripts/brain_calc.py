

from brain_games.games.cli_calc import brain_calc


def main():
    print("Welcome to the Brain Games!")
    brain_calc()


if __name__ == '__main__':
    main()
