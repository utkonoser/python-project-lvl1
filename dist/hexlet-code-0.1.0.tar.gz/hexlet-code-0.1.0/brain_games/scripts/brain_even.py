

from brain_games.cli_even import brain_even


def main():
    print("Welcome to the Brain Games!")
    brain_even()


if __name__ == '__main__':
    main()
